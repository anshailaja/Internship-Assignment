# Task Manager App

## Stack
- Backend: Flask
- Frontend: React
- Database: SQLite

## Run Backend
cd backend
pip install -r requirements.txt
python app.py

## Run Frontend
cd frontend
npm install
npm start
